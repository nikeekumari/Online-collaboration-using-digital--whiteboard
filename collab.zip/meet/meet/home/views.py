from django.shortcuts import render
from django.http import HttpResponse
from .models import *
def home(request):
	name = request.session.get('lname', False)
	print(name)
	email = request.session.get('lemail', False)
	print(email)
	isLogged = request.session.get('isLogged', False)
	con={'name':name,'email':email,'isLogged':isLogged}
	return render(request, 'index.html', con)

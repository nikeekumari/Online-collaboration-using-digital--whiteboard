from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import *

def check(request):
    if request.method=="POST":
        
        action = request.POST.get('action')
        
        if action == "enter_collab":
            collab_id = request.POST.get('collab_id')
            password = request.POST.get('password')
            print(password)
            try:
                user = Collab.objects.get(collab_id=collab_id)
                if(user.password==password):
                    request.session['collab_id'] = user.collab_id
                    return HttpResponse(1)
            except Exception as e:
        # Log the error (optional but useful)
                print(f"Error creating collab: {e}")
                return HttpResponse(11)
        else:
            return HttpResponse(0)
            
    else:
        isLogged = request.session.get('isLogged', False)
        if (isLogged):
            return render(request, 'id_pass.html', {})
        else:
            return redirect('../../auth/login') 
def check4create(request):
    if request.method=="POST":
        action = request.POST.get('action')
        if action == "create_collab":
            collab_id = request.POST.get('collab_id')
            password = request.POST.get('password')
            print(collab_id)
            print(password)
            try:
                user = Collab(collab_id=collab_id, password=password)
                user.save()
                return HttpResponse(1)
            except Exception as e:
        # Log the error (optional but useful)
                print(f"Error creating collab: {e}")
                return HttpResponse(11)
        else:
            return HttpResponse(0)
            
    else:
        isLogged = request.session.get('isLogged', False)
        if (isLogged):
            return render(request, 'create_collab.html', {})
        else:
            return redirect('../../auth/login') 
def host(request):
    print(request.session.get('collab_id', False))
    return render(request,"host.html",{'collab_id':request.session.get('collab_id', False)})